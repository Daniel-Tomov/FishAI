
fish - v1 2022-05-18 11:02am
==============================

This dataset was exported via roboflow.ai on May 18, 2022 at 3:05 PM GMT

It includes 79 images.
Fish are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


